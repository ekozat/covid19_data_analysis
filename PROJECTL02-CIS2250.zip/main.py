#!/usr/bin/env python

'''
This is simply a placeholder file for repl.it - this file does
not need do be edited or examined for CIS*2250.

Please see the README.md file for instructions for this lab.
'''

import pandas as pd
import seaborn as sns
import matplotlib as mpl



print("")
print("This lab requires you to run programs from the command line")
print("")
print("Check the README.md file for instructions")
print("")
print("Version strings:")
print("pandas", pd.__version__)
print("seaborn", sns.__version__)
print("matplotlib", mpl.__version__)
